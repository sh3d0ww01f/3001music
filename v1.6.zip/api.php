<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
<title>Music</title>
<meta name="keywords" content="���ֽ��������ֽ�������163���������ֽ��������������ֽ���"/>
<meta name="description" content="���ֽ���demo v1.0.2��"/>
<link rel="Shortcut Icon" href="/icon/icon.png">
<link rel="stylesheet" href="css/main.css"/>
<link href="https://cdn.bootcss.com/aplayer/1.10.1/APlayer.min.css" rel="stylesheet">
<script src="https://cdn.bootcss.com/aplayer/1.10.1/APlayer.min.js"></script>
</head>
<style>
body{background-image: url("./img/timg.jpg");background-position: center auto; background-repeat:yrepeat; background-attachment: scroll; background-size:100%;}
li{style="list-style-type:none;padding:20px;line-height:80px;text-align:center;}
span{padding:50px;}
</style>
<?php 
header("Content-type:text/html;charset=UTF-8");
function ending(){
unset($cookies_time);
unset($cookies_start);
unset($cookies_end);
unset($ch);
unset($post_data);
}
function getSubstr($str, $leftStr, $rightStr)
{
$left = strpos($str, $leftStr);
//echo '���:'.$left;
$right = strpos($str, $rightStr,$left);
//echo '<br>�ұ�:'.$right;
if($left < 0 or $right < $left) return '';
return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
}
///////////main/////////////////

 function curl_post($url,$filter,$music_name){

	// $a='����Ѹ';
	// $b=mb_convert_encoding($a, 'utf-8', 'gbk');
	// echo urlencode($b);

     $ch = curl_init();
	 curl_setopt($ch, CURLOPT_URL, $url);
	 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	 curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_REFERER, 'http://music.onlychen.cn/'); 
	 curl_setopt($ch, CURLOPT_NOBODY, FALSE);
	 curl_setopt($ch, CURLOPT_HEADER, TRUE);
	 $cookies_time=time();
	 $cookies_start='Cookie: UM_distinctid=17196f296a67d5-0e39bfb0c6cc68-3a365305-140000-17196f296a7738; CNZZDATA1276101445=772842928-';
	 $cookies_end='-https%253A%252F%252Fwww.baidu.com%252F%7C';
     $post_data = array(
        "input" => $music_name,
		//"input" => 'happy',//default
        "filter" => $filter,
		//"filter" => 'name',//default
        "type" => "netease",
        "page" => "1",
         );
	
	$postBody= http_build_query($post_data);
	$headers = array();
    $headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
	$headers[] = 'X-Requested-With: XMLHttpRequest';
	$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36';
	$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
	$headers[] = 'Origin: http://www.youtap.xin';
	$headers[] = 'Referer: http://www.youtap.xin/?name='.$api_name.'&type=netease';
	$headers[] = 'Accept-Language: zh-CN,zh;q=0.9';
	$headers[] = $cookies_start.$cookies_time.$cookies_end.$cookies_time;
    $headers[] = 'Connection: close';
     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $postBody);
     $output= curl_exec($ch);
     curl_close($ch);
     return $output;
}

/*start*/

$name=$_GET['name'];
iconv("UTF-8","gbk//TRANSLIT",$name);
$method=@$_GET['filter'];
$id=@$_GET['id'];

if($method=="name"){
	$text_curl_first=curl_post("http://www.youtap.xin/",$method,$name);
}



$arr_before='{"data":['.getSubstr($text_curl_first,'{"data":[','"code":200,"error":""}').'"code":200,"error":""}';
$obj=json_decode($arr_before, true);
//var_dump(json_decode($arr_before));
//var_dump($obj);




@$count_result=count($obj["data"]);
$song_url[]=array();
$song_id[]=array();
$song_pic[]=array();










//��ȡ�����б�

echo '<link href="https://cdn.bootcss.com/aplayer/1.10.1/APlayer.min.css" rel="stylesheet">'.PHP_EOL;
echo '<div id="aplayer" style="color:#000"></div>'.PHP_EOL;
echo '<script src="https://cdn.bootcss.com/aplayer/1.10.1/APlayer.min.js"></script>'.PHP_EOL;
echo "<script>".PHP_EOL;
echo 'const ap = new APlayer({'.PHP_EOL;
echo "    container: document.getElementById('aplayer'),".PHP_EOL;
echo "       autoplay: true,".PHP_EOL;

echo "    audio: [".PHP_EOL;
for ($i=0;$i<=($count_result+1);$i++){
	if($obj["data"][$i]["url"]!=NULL){
/*	echo '<li style="list-style-type:none";><a href="'.$obj["data"][$i]["url"].'">'.$obj["data"][$i]["title"].'</a></li>'.PHP_EOL;//����url
	echo '<div align="center"><img src="'.$obj["data"][$i]["pic"].'" /></div>'.PHP_EOL;//����ͼƬ
	//echo '<a>'.$obj["data"][$i]["songid"].'</a></p>';//����id*/
	if ($i != $count_result){
echo "{".PHP_EOL;
echo "        name: '".addslashes($obj["data"][$i]["title"])."',".PHP_EOL;
echo "        artist: '".$obj["data"][$i]["author"]."',".PHP_EOL;
echo "        url: '".$obj["data"][$i]["url"]."',".PHP_EOL;
echo "        cover: '".$obj["data"][$i]["pic"]."'".PHP_EOL;
echo "    },".PHP_EOL;
}else{
	echo "{".PHP_EOL;
echo "        name: '".$obj["data"][$i]["title"]."',".PHP_EOL;
echo "        artist: '".$obj["data"][$i]["author"]."',".PHP_EOL;
echo "        url: '".$obj["data"][$i]["url"]."',".PHP_EOL;
echo "        cover: '".$obj["data"][$i]["pic"]."'".PHP_EOL;
echo "    }".PHP_EOL;
}


	}
}
echo "]".PHP_EOL;
echo "}".PHP_EOL;
echo ");".PHP_EOL;
echo "</script>".PHP_EOL;
echo '</ul></nav>'.PHP_EOL;
/*var_dump($obj["data"][2]);*/

/*������°�Ȩлл*/
/*SHADOWWOLF*/

?>

